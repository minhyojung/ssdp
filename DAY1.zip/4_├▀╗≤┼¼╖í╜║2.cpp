#include <iostream>

class Camera
{
public:
	void take() { std::cout << "Camera take" << std::endl; }
};

class People
{
public:
	void useCamera(Camera* p) { p->take(); }
};

int main()
{
	People p;
	Camera c;
	p.useCamera(&c);
}

